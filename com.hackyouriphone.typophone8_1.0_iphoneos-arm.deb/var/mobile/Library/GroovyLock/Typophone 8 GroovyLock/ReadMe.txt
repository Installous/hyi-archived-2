  ████████╗██╗   ██╗██████╗  ██████╗ ██████╗ ██╗  ██╗ ██████╗ ███╗   ██╗███████╗ █████╗
  ╚══██╔══╝╚██╗ ██╔╝██╔══██╗██╔═══██╗██╔══██╗██║  ██║██╔═══██╗████╗  ██║██╔════╝██╔══██╗
     ██║    ╚████╔╝ ██████╔╝██║   ██║██████╔╝███████║██║   ██║██╔██╗ ██║█████╗  ╚█████╔╝
     ██║     ╚██╔╝  ██╔═══╝ ██║   ██║██╔═══╝ ██╔══██║██║   ██║██║╚██╗██║██╔══╝  ██╔══██╗
     ██║      ██║   ██║     ╚██████╔╝██║     ██║  ██║╚██████╔╝██║ ╚████║███████╗╚█████╔╝
     ╚═╝      ╚═╝   ╚═╝      ╚═════╝ ╚═╝     ╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═══╝╚══════╝ ╚════╝

--------------------------
* Theme name: TypoPhone8
* Version: 1.0
* Creator: Anthony Da Mota
* Contact:
      * Email: anthony.damota@icloud.com
      * Twitter: @AkdM_
      * Reddit: AkdM_
* Buy a soda: http://goo.gl/30Ox5W
--------------------------

If you have any problem with my theme, please contact me. I'll make sure your money's worth!

Also if you pirated this, make sure to send a little tweet to support me. If you're kind enough, you can always buy me a soda on the link above! :)

--------------------------

* Changelog:
v1.0:
Initial release.
