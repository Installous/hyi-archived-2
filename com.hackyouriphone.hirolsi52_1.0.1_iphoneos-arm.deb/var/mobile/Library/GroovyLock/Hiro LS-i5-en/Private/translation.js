function ForecastDayNames(day){

switch (day)
  {
//Use these to translate if necessary.  Change the second values, leave the first alone.
    case "Mon": { return "Lun" }
    case "Tue": { return "Mar" }
    case "Wed": { return "Mer" }
    case "Thu": { return "Jeu" }
    case "Fri": { return "Ven" }
    case "Sat": { return "Sam" }
    case "Sun": { return "Dim" }
    case "Today": { return "Aujourd'hui" }
    case "Tonight": { return "Ce Soir" }
  }

}

var Francais =



[
"Tornade",
"Orage Tropical",
"Ouragan",
"Orages",
"Orages",
"Pluie et Neige",
"Pluie et Verglas",
"Neige et Verglas",
"Brouillard VerglaÃ§ant",
"Brouillard",
"Pluie VerglaÃ§ante",
"Averses",
"Averses",
"Bourrasques de neige",
"Petites chutes de neige",
"Chutes de neige - Vent",
"Neige",
"grÃªle",
"Verglas",
"Non communiquÃ©",
"brumeux",
"Brume",
"Non communiquÃ©",
"Non communiquÃ©",
"Vent",
"Froid",
"Nuageux",
"Passages nuageux",
"Passages nuageux",
"Passages nuageux",
"Passages nuageux",
"Ciel Clair",
"EnsoleillÃ©",
"Clair",
"Beau Temps",
"Pluie et GrÃªle mÃ©langÃ©es",
"TrÃ¨s Chaud",
"Passages nuageux avec orages",
"Orage et Ã©claircies",
"Orage et Ã©claircies",
"Pluies et Ã©claircies",
"Chute de neige importante",
"Petite chutes de neige",
"Chute de neige importante",
"Partiellement couvert",
"Tonnerre",
"Chutes de neige",
"Tonnerre et Ã©claircies",
"Pas d'info",
]


var English = "English" //Leave Alone