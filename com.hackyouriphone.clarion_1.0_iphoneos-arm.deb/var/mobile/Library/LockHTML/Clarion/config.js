var TextColor = "Black";
var HighlightColor = "linear-gradient(to top, #ff0099, #493240)";
var DarkIcon = true;
var ZoomLevel = 100;
