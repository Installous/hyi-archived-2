/*
Configurations
Credits: original code by Dacal & Junesiphone. Modified by Evelyn.
*/
var Clock = "12h"; // choose between "12h" or "24h"
var Lang = "en"; // choose between "en", "ca", "fr", "de", "it", "ru", "pl", "pt", "cz"
//Widget position with notifications//
var ShiftUp_Notif = "0"; // -ve value to shift up. +ve value to shift down
var OriginalPos = "0"; // shift up or down widget elements besides battery
/* No need to configure the following if you're using IS2 (default HTML) */
var weathercode = 'USUT0222'; // get weather code from www.weather.com, search for your city, code can be found in address bar.
var celsius = false;
var gpsswitch = false;
var refreshrate = 10; // update interval of weather, in minutes
var IconSet = "Climacons"; // choose your weather icon pack here