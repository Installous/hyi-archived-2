#!/bin/sh

function backup {
        mv /var/mobile/Library/$1 /var/mobile/Library/Caches/igotya/
}

function restore {
	rm -R /var/mobile/Library/$1
	mv /var/mobile/Library/Caches/igotya/$1 /var/mobile/Library/
}

function enter {
        echo "Entering into Secure Mode..."
        mkdir /var/mobile/Library/Caches/igotya/
        mkdir /var/mobile/Library/Caches/igotya/prefs
        mkdir /var/mobile/Library/Caches/igotya/media
        mkdir /var/mobile/Library/Caches/igotya/apps
        touch /var/mobile/Library/Caches/igotya/failsafe

#        launchctl unload /System/Library/LaunchDaemons/com.apple.searchd.plist
#        launchctl unload /System/Library/LaunchDaemons/com.apple.CommCenter.plist
#        launchctl unload /System/Library/LaunchDaemons/com.apple.CommCenterClassic.plist
#        launchctl unload /System/Library/LaunchDaemons/com.apple.SpringBoard.plist
#        launchctl unload /System/Library/LaunchDaemons/com.apple.backboardd.plist

        backup SpringBoard
        backup Notes
        #backup SMS
	backup AddressBook
	backup Calendar
	backup Mail
	mv /var/mobile/Library/Preferences/* /var/mobile/Library/Caches/igotya/prefs; cp /var/mobile/Library/Caches/igotya/prefs/com.igotya.settings.plist /var/mobile/Library/Preferences/; chmod 644 /var/mobile/Library/Preferences/com.igotya.settings.plist; cp /var/mobile/Library/Caches/igotya/prefs/com.apple* /var/mobile/Library/Preferences/; chown mobile:mobile /var/mobile/Library/Preferences/com.apple*
	rm /var/mobile/Library/Preferences/*account*
	rm /var/mobile/Library/Preferences/*mail*
	mv /var/mobile/Media/* /var/mobile/Library/Caches/igotya/media
	mv /Applications/MobileSMS.app/MobileSMS /Applications/MobileSMS.app/MobileSMS_
	mv /var/mobile/Applications /var/mobile/Library/Caches/igotya/apps
	killall MobileSMS
	killall MobileCal
	killall MobileMail
	killall Contacts
	killall Contacts~iphone
	killall Contacts~ipod
	killall Contacts~ipad
	killall MobilePhone
	killall MobileSlideShow
	rm -R /var/mobile/Library/SpringBoard/; cp /var/mobile/Library/Caches/igotya/SpringBoard/Icon* /var/mobile/Library/SpringBoard/
#	chown -R mobile:mobile /var/mobile/Library/SpringBoard
#	launchctl load /System/Library/LaunchDaemons/com.apple.locationd.plist
#	launchctl load /System/Library/LaunchDaemons/com.apple.CommCenter.plist
#	launchctl load /System/Library/LaunchDaemons/com.apple.CommCenterClassic.plist
	chown mobile:mobile /var/mobile/Library/Preferences/com.apple.springboard.plist
#	launchctl load /System/Library/LaunchDaemons/com.apple.backboardd.plist
#        launchctl load /System/Library/LaunchDaemons/com.apple.SpringBoard.plist
}

function exitf {
        echo "Exiting from Secure Mode..."

        launchctl unload /System/Library/LaunchDaemons/com.apple.SpringBoard.plist
        launchctl unload /System/Library/LaunchDaemons/com.apple.CommCenter.plist
        launchctl unload /System/Library/LaunchDaemons/com.apple.CommCenterClassic.plist
        launchctl unload /System/Library/LaunchDaemons/com.apple.backboardd.plist

	restore SpringBoard
	restore Notes
	#restore SMS
	restore AddressBook
	restore Calendar
	restore Mail
	mv /Applications/MobileSMS.app/MobileSMS_ /Applications/MobileSMS.app/MobileSMS
	mv /var/mobile/Library/Caches/igotya/apps/Applications /var/mobile/
	rm -R /var/mobile/Library/Preferences/*; mv /var/mobile/Library/Caches/igotya/prefs/* /var/mobile/Library/Preferences/
	rm -R /var/mobile/Media/*; mv /var/mobile/Library/Caches/igotya/media/* /var/mobile/Media/
        launchctl load /System/Library/LaunchDaemons/com.apple.searchd.plist
        launchctl load /System/Library/LaunchDaemons/com.apple.CommCenter.plist
        launchctl load /System/Library/LaunchDaemons/com.apple.CommCenterClassic.plist
	launchctl load /System/Library/LaunchDaemons/com.apple.SpringBoard.plist
        launchctl load /System/Library/LaunchDaemons/com.apple.backboardd.plist

	rm /var/mobile/Library/Caches/igotya/failsafe
}

if [ "$1" == "enter" ]
then
	enter;
else

	if [ -f /var/mobile/Library/Caches/igotya/failsafe ]
	then
		exitf;
	else
		echo "Not in secure mode"
	fi
fi

