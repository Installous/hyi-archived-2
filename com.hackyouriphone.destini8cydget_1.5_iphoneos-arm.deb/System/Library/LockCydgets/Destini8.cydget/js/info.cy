var url = "cydia://package/com.macciti.destini8cydget";
var exist = [[NSFileManager defaultManager] fileExistsAtPath: @"/var/lib/dpkg/info/com.macciti.destini8cydget.list"];
