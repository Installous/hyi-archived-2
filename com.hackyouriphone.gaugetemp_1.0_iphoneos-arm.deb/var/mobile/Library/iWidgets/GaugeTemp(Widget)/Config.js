var Scale = "0.8"; // Change Size Widget
var Clock = "12h"; // Choose between "12h" or "24h"
var BackTempColor = "silver"; // Change color Background for temp
var TextColor = "#fff"; // Change color text
var BlueTemp = false; 
