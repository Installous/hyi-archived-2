/* *************************************** */
/* The following scripts will allow you to finetune */
/* *************************************** */

/* ********* Configure Your Weather Widget here ********* */
/* Step 1 - Find YOUR city code (locale) here : http://weather.yahoo.com/
/* Step 2 - Then enter your city code here */
var locale = "FRIF0084";

/* language */
var lang = "fr"; // Available : (en)glish, (de)utch or (fr)ench

/* Use Celsius or not */
var isCelsius = true;

/* Use Real Feel Temperature or not */
var useRealFeel = false;

/* Minutes between updates */
var updateInterval = 15;

//Toggles twelve and twenty-four hour time.
var twentyFourHourTime = true;

/* ************** CALENDAR *************** */
var WeekStartMonday = true;
