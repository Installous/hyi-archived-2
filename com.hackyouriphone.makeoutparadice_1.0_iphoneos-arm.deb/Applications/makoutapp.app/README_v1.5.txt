
May 11, 2011
buzztouch v1.5 "Schooner" for iOS

This document is intended to help buzztouch Early Adopters understand the purpose of the
buzztouch Early Adopter program. The buzztouch Early Adopter program tries to do three things:

a)	It hopes to reward site visitors showing genuine interest in our products and services with
    early, and potentially exclusive releases of our software.
b)  It hopes to generate interest around our latest body of work with a focus on listening, 
    listening, listening.
c)  It hopes to help direct the direction of our efforts as it relates to public releases of
    our products and services. 
    
PLEASE BE PATIENT and OPEN MINDED when exploring the newest, latest, and potentially buggy
software releases that we make available you. We trust that because you expressed an interest
in being an "Early Adopter" that you understand the inherent risks associated with being FIRST.

YOUR FEEDBACK IS TREMENDOUSLY USEFUL AND IMPORTANT.


Please visit the forum at buzztouch.com to add comments, questions, or feedback about this
early release. Your help is greatly appreciated. Technical feedback is good, promotional
plugs are better! Tweeting, Blogging, or linking to us from your website is the single
biggest way you can help. We consider each and every one of our supporters to be our 
biggest asset and as such, depend on their helping us improve, promote, and publicize
our exciting project. Thank you in advance for this. 


Getting Started - YOU MUST HAVE XCODE TO USE THIS SOFTWARE. 4.0.2 is the latest release, older
releases may work but remain untested.

a)  Unzip the downloaded source-code directory and double click the Xcode icon (blue) to open
    the project in Xcode.

b) Select "Simulator - iPhone 4.2" from the top-left-most drop down list in Xcode

c) Click "Build and Run" from the toolbar. 

The simulator should launch and your buzztouch application should load. Use the Refresh button
on the app's home screen to pull changes you make on the buzztouch control panel to your app.


A NOTE ABOUT iOS FRAMEWORKS
----------------------------------------
The project relies on several iOS packages knows as "frameworks" that are installed in your development
machine when you install the iOS SDK. The frameworks on your development machine are located in different
places in your files system, depending on the SDK version you are running. This means you may need to 
"Add Existing Frameworks" to the Xcode project if you have trouble compiling. 

Necessary Frameworks (look in the Frameworks folder in the Xcode project)
----------------------------------------
CoreAudio.framework
CoreLocation.framework
Foundation.framework
SystemConfiguration.framework
UIKit.framework
MobileCoreServices.framework
AVFoundation.framework
MessageUI.framework
libxml2.dylib
MapKit.framework
MediaPlayer.framework
CoreGraphics.framework
QuartzCore.framework




	
	
	

