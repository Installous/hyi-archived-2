
/*
	This is a simple Javascript file for demonstration purposes. It is included
	in the <head> of the sample.html document.

	IMPORTANT: IF YOU INCLUDE .JS FILES IN YOUR XCODE PROJECT YOU MAY SEE THIS
	WARNING WHEN COMPILING, OR, THE Javscript FILE WILL NOT BEHAVE AS EXPECTED.
		
	"warning: no rule to process file '$(PROJECT_DIR)/sample.js' of type sourcecode.javascript 
	for architecture i386"

	TO FIX THIS, YOU MUST TELL XCODE NOT TO COMPILE THE .JS SOURCE CODE FILE, DO THIS IN THIS ORDER:
	
	a)	Expand your target in the Groups and Files list
	b)	Remove the JavaScript file from the Compile Sources folder if it exists. 
		Expand Targets >  project-name > Compile Sources
	c) 	Click and drag the javascript file into the Copy Bundle Resources folder. 
		Exapand Targets > project-name > Copy Bundle Resources 
		This process does not move the actual file. 
	
*/

//simple date function
function myCoolDate(){
	var myDate = new Date();
	return myDate.toUTCString();
}















