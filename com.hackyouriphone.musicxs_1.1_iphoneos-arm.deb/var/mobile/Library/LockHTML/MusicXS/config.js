var BackgroundArtwork = true;
var MusicFromBottom = 50;
var TextColour = "Black";
