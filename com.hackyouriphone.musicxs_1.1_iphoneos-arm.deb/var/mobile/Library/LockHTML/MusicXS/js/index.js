$('.ani_class').on("click", function() {
  $('.music_container').slideToggle( 1000, function() {
    $('.music_container_inner').show( 100 );
  });
});
