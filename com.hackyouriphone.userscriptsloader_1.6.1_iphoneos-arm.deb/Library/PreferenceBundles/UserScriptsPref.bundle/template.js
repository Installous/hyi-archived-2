
if (typeof String.prototype.hashCode === 'undefined') {
    String.prototype.hashCode = function(){
        var hash = 0, i, chr, len;
        if (this.length === 0) return hash;
        for (i = 0, len = this.length; i < len; i++) {
            chr   = this.charCodeAt(i);
            hash  = ((hash << 5) - hash) + chr;
            hash |= 0; // Convert to 32bit integer
        }
        return hash;
    }
}

if (typeof sc_xmlHttpRequests === 'undefined') {
    var sc_xmlHttpRequests = {};
}

if (typeof sc_handleXmlHttpResponse === 'undefined') {
    sc_handleXmlHttpResponse = function (requestID, text) {
        if (!requestID in sc_xmlHttpRequests) {
            return;
        }
        var request = sc_xmlHttpRequests[requestID];
        text = atob(text);
        var resp = JSON.parse(text);

        if (resp.status / 100 == 2) {
            if (request.onload) {
                request.onload(resp);
            }
        } else {
            if (request.onerror) {
                request.onerror(resp);
            }
        }
        delete sc_xmlHttpRequests[requestID];
    };
}

if (typeof GM_xmlhttpRequest === 'undefined') {
    GM_xmlhttpRequest = function(opt) {
        var json = JSON.stringify(opt);
        var requestID = "" + json.hashCode();
        sc_xmlHttpRequests[requestID] = opt;
        
        if (typeof(window.UserScriptBridge) !== 'undefined')  {
            window.UserScriptBridge.xmlHTTPRequest(btoa(json), requestID);
        } else {
            prompt("userscritp_prompt=GM_xmlhttpRequest;requestID=" + requestID+";request=" + btoa(json));
        }
        
//        var xhr = new XMLHttpRequest();
//        var res = {
//        status: 0,
//        statusText: '',
//        readyState: 0,
//        responseText: '',
//        responseHeaders: ''
//        };
//        
//        xhr.open(opt.method, opt.url, true);
//        
//        if (xhr.overrideMimeType && opt.overrideMimeType) {
//            xhr.overrideMimeType(opt.overrideMimeType);
//        }
//        if (opt.onload) {
//            xhr.onload = function() {
//                Object.keys(res).forEach(function(k) {
//                                         res[k] = xhr[k];
//                                         });
//                opt.onload(res);
//            };
//        }
//        if (opt.onerror) {
//            xhr.onerror = function() {
//                Object.keys(res).forEach(function(k) {
//                                         res[k] = xhr[k];
//                                         });
//                opt.onerror(res);
//            };
//        }
//        if (opt.onreadystatechange) {
//            xhr.onreadystatechange = function() {
//                Object.keys(res).forEach(function(k) {
//                                         res[k] = xhr[k];
//                                         });
//                opt.onreadystatechange(res);
//            };
//        }
//        xhr.send(opt.data);
    }
}

if (typeof GM_getResourceText  === 'undefined') {
    GM_getResourceText = function(key) {
        if (typeof(window.UserScriptBridge) !== 'undefined') {
            return window.UserScriptBridge.getResourceText(key, this.currentScripteIdentifier);
        } else {
            return prompt("userscritp_prompt=GM_getResourceText;key=" + key + ";id=" + this.currentScripteIdentifier);
        }
    }
}
if (typeof GM_getResourceURL  === 'undefined') {
    GM_getResourceURL = function(key) {
        if (typeof(window.UserScriptBridge) !== 'undefined') {
            return window.UserScriptBridge.getResourceURL(key, this.currentScripteIdentifier, this.resourceKeyAndMime[key]);
        } else {
            return prompt("userscritp_prompt=GM_getResourceURL;key=" + key + ";id=" + this.currentScripteIdentifier + ";mime=" + this.resourceKeyAndMime[key]);
        }
    }
}


if (typeof GM_log === 'undefined') {
    GM_log = function(data) {
        console.log(data);
    };
}

if (typeof(unsafeWindow) == 'undefined') {
    unsafeWindow = window;
}

if (typeof GM_addStyle == 'undefined') {
    GM_addStyle = function(css) {
        var node = document.createElement("style");
        node.type = "text/css";
        node.appendChild(document.createTextNode(css));
        var heads = document.getElementsByTagName("head");
        if (heads.length > 0) {
            heads[0].appendChild(node);
        } else {
            document.documentElement.appendChild(node);
        }
    };
}

if (typeof GM_openInTab == 'undefined') {
    GM_openInTab = function(url) {
        return window.open(url, "_blank");
    };
}

if (typeof GM_registerMenuCommand == 'undefined') {
    GM_registerMenuCommand = function(name, funk) {
    };
}

if (typeof GM_setValue == 'undefined') {
    var storageTypes = ["localStorage", "sessionStorage"];
    var storage, name;
    for (var i = 0; i < storageTypes.length; i++) {
        if (this[storageTypes[i]]) {
            storage = this[storageTypes[i]];
            name = storageTypes[i];
            break;
        }
    }
    
    if (storage) {
        try {
            storage.length;
            storage.getItem("dummy");
        } catch (e) {
            storage = null;
        }
    }
    
    if (storage) {
        GM_setValue = function(name, value) {
            value = (typeof value)[0] + value;
            storage.setItem(this.currentScripteIdentifier + name, value);
        };

        GM_getValue = function(name, defaultValue) {
            var value = storage.getItem(this.currentScripteIdentifier + name);
            if (!value) return defaultValue;
            var type = value[0];
            value = value.substring(1);
            switch (type) {
                case 'b':
                    return value == 'true';
                case 'n':
                    return Number(value);
                default:
                    return value;
            }
        };
        
        GM_deleteValue = function(name) {
            storage.removeItem(this.currentScripteIdentifier + name);
        };

        GM_listValues = function() {
            var list = [];
            for (var i = 0; i < storage.length; i++) {
                var key = storage.key(i).replace(this.currentScripteIdentifier, "");
                list.push(key);
            }

            return list;
        };
    }
}