

function init ( ){

  timeDisplay = document.createTextNode ( "" );
document.getElementById("clock").appendChild ( timeDisplay );
}

function updateClock () {

        var currentTime = new Date ();
        var currentHours = currentTime.getHours ();
        var currentMinutes = currentTime.getMinutes ();
        var currentSeconds = currentTime.getSeconds ();
        timeOfDay = ( currentHours < 12 ) ? "am" : "pm";

        if (twentyfourhour  == true) {

        timeOfDay = "";

     // Pad the hours, minutes and seconds with leading zeros, if required

        currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours; 
        currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;
        currentSeconds = ( currentSeconds < 10 ? "0" : "" ) + currentSeconds;

        var currentTimeString = currentHours + ":" + currentMinutes;

document.getElementById("clock").firstChild.nodeValue = currentTimeString;
       document.getElementById("ampm").innerHTML = timeOfDay;

        } else {

        currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;

        currentHours = ( currentHours == 0 ) ? 12 : currentHours;

        currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;

        currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;

        currentSeconds = ( currentSeconds < 10 ? "0" : "" ) + currentSeconds;

        var currentTimeString = currentHours + ":" + currentMinutes;

        currentTimeString1 = timeOfDay;

document.getElementById("clock").firstChild.nodeValue = currentTimeString ;

document.getElementById("ampm").firstChild.nodeValue = currentTimeString1;

        }
    }

 function init2 ( ) {

   timeDisplay = document.createTextNode ( "" );
  document.getElementById("calendar").appendChild ( timeDisplay );
 }

 function calendarDate ( ) {

        var this_weekday_name_array=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];

        var this_month_name_array=["January","February","March","April","May","June","July","August","September","October","November","December"];



        if (French == true){

        var this_weekday_name_array=["Dimanche","Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi"];

       var this_month_name_array=['Janvier','Fevrier','Mars','Avril','Mai','Juin','Juillet','Aout','Septembre','Octobre','Novembre','Decembre'];

        }

        if (German == true){

        var this_weekday_name_array = ["Sonntag","Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag"];

       var this_month_name_array=["Januar","Februar","Marz","April","Mai","Juni","Juli","August","September ","Oktober","November","Dezember"];

        }

        if (Spanish == true){

        var this_weekday_name_array = ["Domingo","Lunes","Martes","Miercoles","Jueves","Viernes","Sabado"];

        var this_month_name_array=['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Deciembre'];

        }

        if (Dutch == true){

        var this_weekday_name_array = ["zondag","maandag","dinsdag","woensdag","donderdag","vrijdag","zaterdag"];

        var this_month_name_array=['januari','februari','maart','april','mei','juni','juli','augustus','september','oktober','November','December'];

        }

        if (Italian == true){

        var this_weekday_name_array = ["Domenica","Lunedi","Martedi","Mercoledi","Giovedi","Venerdi","Sabato"];

        var this_month_name_array=['Gennaio','Febbraio','Marzo','Aprile','Maggio','Giugno','Luglio','Agosto','Settembre','Ottobre','Novembre','Dicembre'];

        }


   var this_date_timestamp = new Date()

   var this_weekday = this_date_timestamp.getDay()
   var this_date = this_date_timestamp.getDate()
   var this_month = this_date_timestamp.getMonth()
   var this_year = this_date_timestamp.getYear()  
   
if (this_year < 1000)
    this_year+= 1900;
if (this_year==101)
    this_year=2001;        

document.getElementById("calendar").firstChild.nodeValue = this_weekday_name_array[this_weekday] + " " + this_date + " " + this_month_name_array[this_month] //concat long date string

document.getElementById("month").firstChild.nodeValue = this_month_name_array[this_month]  //concat long date string

document.getElementById("weekday").firstChild.nodeValue = this_weekday_name_array[this_weekday] //concat long date string

document.getElementById("year").firstChild.nodeValue = this_year 
 }