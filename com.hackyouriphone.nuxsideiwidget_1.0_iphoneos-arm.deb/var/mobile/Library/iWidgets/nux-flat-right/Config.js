/*
Configuration here !
Done by Dacal - Modded by Schnedi
For weather code, go to http://weather.yahoo.com/ and search for your city. The correct zip code is in the URL (only numbers)
*/


var Clock = "24h";		  // choose between "12h" or "24h"
var IconSet = "nux";	    // add your own set