var twentyFourHourTime = false;
//Set to true for twenty-four hour time.