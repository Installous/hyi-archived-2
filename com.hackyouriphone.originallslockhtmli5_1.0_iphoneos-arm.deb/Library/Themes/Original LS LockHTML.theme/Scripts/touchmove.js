var forecastdisplay = true;

if (ChangeClick == false) { var touchmode = "touchend"; } else { var touchmode = "click"; }

function StartTouch() {
document.getElementById("TouchLayer").addEventListener(touchmode, touchEnd, false); // FOR THE FORECAST
}

function touchEnd() {
	if (forecastdisplay == false) {
		document.getElementById('InfoWeather').className = "infoMoveUp";
		document.getElementById('forecast').className = "forecastMoveUp";

		forecastdisplay = true;
	} else {
		document.getElementById('InfoWeather').className = "infoMoveDown";
		document.getElementById('forecast').className = "forecastMoveDown";
		forecastdisplay = false;
	}
}


