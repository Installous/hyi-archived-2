// exxOS LiveClock Modifikation by thewaytozion, Base Code from 

// Configuration


var ampm = true;                        // Set to true for 12h format and to false for 24h format

// position your Icon - CHECK ICONOCLASM PLIST
var xvalue = 154; // values from 0 to 260
var yvalue = 34; // values from 20 to 420 (0 to 400 for perpagesHTML) (iphone 4 noDock)

// Choose your Icon clock Icon style

var IconStyle = "exxOS";




// Set your clock Font color
var ClockColor = "deepskyblue";
//var ClockColor = "black";
//var ClockColor = "#99cc00";    // green
//var ClockColor = "#3399FF"; // blue
//var ClockColor = "cyan";
//var ClockColor = "#999";  // grey
//var ClockColor = "#eee8aa";  // light gold
//var ClockColor = "red";
//var ClockColor = "#33cccc";  //Turquoise
//var ClockColor = "white";

