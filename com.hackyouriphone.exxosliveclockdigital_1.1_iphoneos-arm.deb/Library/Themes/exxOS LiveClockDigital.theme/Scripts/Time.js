function updateClock ( )

{

  var currentTime = new Date ( );

  var currentHours = currentTime.getHours ( );

  var currentMinutes = currentTime.getMinutes ( );

  var currentSeconds = currentTime.getSeconds ( );

  // Pad the minutes and seconds with leading zeros, if required

  currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;

  currentSeconds = ( currentSeconds < 10 ? "0" : "" ) + currentSeconds;



if (ampm == false) {

  var currentTime = new Date ( );

  var currentHours = currentTime.getHours ( );

  var currentMinutes = currentTime.getMinutes ( );

  var currentSeconds = currentTime.getSeconds ( );

  // Pad the minutes and seconds with leading zeros, if required

  currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;

  currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;

  currentSeconds = ( currentSeconds < 10 ? "0" : "" ) + currentSeconds;

	} else {

  var currentTime = new Date ( );

  var currentHours = currentTime.getHours ( );

  var currentMinutes = currentTime.getMinutes ( );

  var currentSeconds = currentTime.getSeconds ( );

  // Pad the minutes and seconds with leading zeros, if required

  currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;

  currentSeconds = ( currentSeconds < 10 ? "0" : "" ) + currentSeconds;

  var timeOfDay = ( currentHours < 12 ) ? "AM" : "PM";

  currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;

//Pad PM hours with leading zero's 

currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;

  currentHours = ( currentHours == 0 ) ? 12 : currentHours;

}



  // Compose the string for display

var currentTimeString = currentHours + " "  +  currentMinutes;



  // Update the time display

document.getElementById("hours").firstChild.nodeValue = currentHours;
document.getElementById("minutes").firstChild.nodeValue = currentMinutes;

}



