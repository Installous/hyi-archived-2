#!/bin/bash

#######################
# GuizmOVPN_updown.sh #
# Version 1.1.0       #
#######################

function CopyKey
{
	if [ "`KeyExists $1`" == "NO" ] ; then
		return
	fi
        source=$1;
        dest=$2;
	error="0";
        echo "d.init" >/tmp/tmpscutil
        for param in `echo "show $1" | /usr/sbin/scutil | grep -v "<dictionary>" | tr -d '\n' | tr '}' '\n' | awk '{ print $1 }'` ; do
                value=`echo "show $1" | /usr/sbin/scutil| grep -v "<dictionary>" | tr -d '\n' | tr '}' '\n' | grep $param`
		if $( echo $value | grep --quiet '<array>' ) ; then
                        unset array_val
                        for arraynum in 2 3 4 5 6 7 8 9 ; do
                                val=`echo $value | cut -d '{' -f 2 | cut -d ':' -f $arraynum | cut -d ' ' -f 2`
                                if [ "$val" != "" ] ; then
                                        array_val[$(($arraynum-1))]=$val;
                                fi
                        done
                        if [ ${#array_val[@]} ]; then
                                echo "d.add $param * ${array_val[*]}" >>/tmp/tmpscutil
                       	else
				error="1" 
			fi
                else
                        val=`echo "$value" | awk '{ print $3 }'`
                        if [ "`echo "$val" | tr -d ' '`"  == "" ] ; then
                                error="1";
                        else
                                echo "d.add $param $val" >>/tmp/tmpscutil
                        fi
                fi

        done
        echo "set $dest" >>/tmp/tmpscutil
	if [ "$error"=="0" ] ; then
		cat /tmp/tmpscutil | /usr/sbin/scutil
	else
		echo "Error reading key $1"
	fi	
}

function GetActualDNS
{
	OLDDNS=`echo "show State:/Network/Service/$1/DNS" | /usr/sbin/scutil | grep -A 1 "ServerAddresses : " | grep "0 : " | awk '{print $3}' | tr -d " "`
	echo $OLDDNS 	
}

function KeyExists
{
	if [ "`echo "show $1" | /usr/sbin/scutil | tr -d " "`" == "Nosuchkey" ] ; then
		echo "NO" ;
	else
		echo "YES" ;
	fi
}

PSID=$( (/usr/sbin/scutil | grep PrimaryService | sed -e 's/.*PrimaryService : //')<< EOF
open
get State:/Network/Global/IPv4
d.show
quit
EOF
)

case "$script_type" in
   up)
     # Stop the APSd
     #/bin/launchctl unload /System/Library/LaunchDaemons/com.apple.apsd.plist
    
     # Stop the dataaccesd
     /bin/launchctl unload /System/Library/LaunchDaemons/com.apple.dataaccess.dataaccessd.plist
 
     # Remove informations about a previous connection
     echo "remove State:/Network/Service/OpenVPN/DNS" | /usr/sbin/scutil >/dev/null 2>&1
     echo "remove State:/Network/Service/OpenVPN/IPv4" | /usr/sbin/scutil >/dev/null 2>&1
     echo "remove State:/Network/Service/OpenVPN/PPP" | /usr/sbin/scutil >/dev/null 2>&1
     echo "remove State:/Network/Service/OpenVPN/PSID" | /usr/sbin/scutil >/dev/null 2>&1
 
     # Check if we need to handle DNSPush
     unset dns
     unset domain
     if [ "$DNSPush" == "Y" ] ; then
	# Store the PSID that we modify, in order to restore the correct one on disconnection
        if [ "$PSID" != "" ] ; then
                echo "d.init" >/tmp/tmpscutil
                echo "d.add PSID $PSID" >>/tmp/tmpscutil
                echo "set State:/Network/Service/OpenVPN/PSID" >>/tmp/tmpscutil
                cat /tmp/tmpscutil | /usr/sbin/scutil
        fi

	# Save the DNS settings
	# If it has already been set, don't save it again
	if [ "`KeyExists State:/Network/Global/DNSold`" == "NO" ] ; then 
		CopyKey Setup:/Network/Service/$PSID/DNS Setup:/Network/Service/$PSID/DNSold ; 
		CopyKey State:/Network/Service/$PSID/DNS State:/Network/Service/$PSID/DNSold ;
		CopyKey State:/Network/Global/DNS State:/Network/Global/DNSold ;	
	fi

     	n=1; i=0; j=0;
     	while o=foreign_option_${n}; o=${!o}; [ "$o" ]
     	do
           case $o in
           	'dhcp-option DNS '*)        dns[i++]=${o/dhcp-option DNS /};;
             	'dhcp-option DOMAIN '*)     domain[j++]=${o/dhcp-option DOMAIN /} ;;
           esac;
           let n++
     	done

	# Check if we need to try to keep local DNS
     	if [ "$DNSKeep" == "Y" ] ; then
		# If DNS push has been set, add the actual DNS in the list, in case the DNS pushed don't respond
		if [ $i != 0 ] && [ $i -le 3 ] ; then
        		dns[i]=`GetActualDNS $PSID`;
	 
	 		# Check if the DNS is different from the gateway IP.
	 		# If it's the case, add a route to it
	 		if [ "$traffic_is_redirected" == "1" ] && [ "$dns[i]" != "" ] && [ "$route_net_gateway" != "${dns[i]}" ] && [ "$route_net_gateway" != "" ] ; then
				echo "Add a route to ${dns[i]} with gateway $route_net_gateway" ;
				/sbin/route add -net ${dns[i]} $route_net_gateway 255.255.255.255;
	 		fi 
     		fi
	fi

     	if [ "${dns[0]}" != "" ] ; then
		echo "Setting DNS to /Network/Service/$PSID/DNS (${dns[*]})"
		echo "d.init" >/tmp/tmpscutil
        	echo "d.add ServerAddresses * ${dns[*]}" >>/tmp/tmpscutil 
		if [ "${domain[0]}" != "" ] ; then
			echo "Setting domain to /Network/Service/$PSID/DNS (${domain[*]})"	
			echo "d.add SupplementalMatchDomains * ${domain[*]}" >>/tmp/tmpscutil
		fi
		echo "set State:/Network/Service/$PSID/DNS" >>/tmp/tmpscutil	
		
		cat /tmp/tmpscutil | /usr/sbin/scutil 

		# For a strange reason, some devices don't use the "State" but the "Setup", so we copy the key.
		if [ "`KeyExists Setup:/Network/Service/$PSID/DNS`" == "YES" ] ; then
	                CopyKey State:/Network/Service/$PSID/DNS Setup:/Network/Service/$PSID/DNS 
                fi
		CopyKey State:/Network/Service/$PSID/DNS State:/Network/Service/OpenVPN/DNS 
                CopyKey State:/Network/Service/$PSID/DNS State:/Network/Global/DNS 
	fi
     fi
     
     # Add informations about the connection
     # IPv4
     echo "d.init" >/tmp/tmpscutil
     echo "d.add DestAddresses * $trusted_ip" >>/tmp/tmpscutil
     echo "d.add ServerAddress $trusted_ip" >>/tmp/tmpscutil
     echo "d.add InterfaceName ppp0" >>/tmp/tmpscutil
     echo "d.add Addresses * $ifconfig_local" >>/tmp/tmpscutil
     echo "d.add SubnetMasks * 255.255.255.255" >>/tmp/tmpscutil
     echo "d.add NetworkSignature VPN.RemoteAddress=$trusted_ip" >>/tmp/tmpscutil
     echo "set Setup:/Network/Service/OpenVPN/IPv4" >>/tmp/tmpscutil
     echo "set State:/Network/Service/OpenVPN/IPv4" >>/tmp/tmpscutil

     # PPP
     echo "d.init" >>/tmp/tmpscutil
     echo "d.add Status 8" >>/tmp/tmpscutil
     echo "d.add InterfaceName ppp0" >>/tmp/tmpscutil
     echo "set Setup:/Network/Service/OpenVPN/PPP" >>/tmp/tmpscutil
     echo "set State:/Network/Service/OpenVPN/PPP" >>/tmp/tmpscutil
     
     # Interface
     echo "d.init" >>/tmp/tmpscutil
     echo "d.add Type PPP" >>/tmp/tmpscutil
     echo "d.add SubType OpenVPN" >>/tmp/tmpscutil
     echo "set Setup:/Network/Service/OpenVPN/Interface" >>/tmp/tmpscutil
 
     cat /tmp/tmpscutil | /usr/sbin/scutil

     # Add infos about connection to be displayed in GUI
     /Applications/GuizmOVPN.app/tools writeprefs InfosIPAddress "$ifconfig_local"
     if [ "$ifconfig_netmask" == "" ] ; then
          /Applications/GuizmOVPN.app/tools writeprefs InfosSubnetMask "255.255.255.255"
	  /Applications/GuizmOVPN.app/tools writeprefs InfosGateway "$ifconfig_remote"
     else
          /Applications/GuizmOVPN.app/tools writeprefs InfosSubnetMask "$ifconfig_netmask"
	  /Applications/GuizmOVPN.app/tools writeprefs InfosGateway "$InfosGateway"
     fi
     /Applications/GuizmOVPN.app/tools writeprefs InfosTrafficRedirected "$traffic_is_redirected"

     # Start the dataaccessd
     /bin/launchctl load /System/Library/LaunchDaemons/com.apple.dataaccess.dataaccessd.plist

     # Start the APSd
     #/bin/launchctl load /System/Library/LaunchDaemons/com.apple.apsd.plist
   ;;

   down)
     # Remove the connection infos
     /Applications/GuizmOVPN.app/tools writeprefs InfosIPAddress "" 
     /Applications/GuizmOVPN.app/tools writeprefs InfosSubnetMask ""
     /Applications/GuizmOVPN.app/tools writeprefs InfosGateway ""
     /Applications/GuizmOVPN.app/tools writeprefs InfosTrafficRedirected ""

      # Check if we have a stored PSID. If not, take the actual one
      OLD_PSID=`echo "show State:/Network/Service/OpenVPN/PSID" | /usr/sbin/scutil | grep PSID | awk '{print $3}'`
      if [ "$OLD_PSID" == "" ] ; then
          OLD_PSID=$PSID
      fi
 
      # If we have saved DNS, restore them
      if [ "$OLD_PSID" != "" ] && [ "`KeyExists State:/Network/Global/DNSold`" == "YES" ] ; then
          echo "Restoring DNS to $OLD_PSID";
          CopyKey Setup:/Network/Service/$OLD_PSID/DNSold Setup:/Network/Service/$OLD_PSID/DNS ;
          CopyKey State:/Network/Service/$OLD_PSID/DNSold State:/Network/Service/$OLD_PSID/DNS ;
          CopyKey State:/Network/Global/DNSold State:/Network/Global/DNS ;

	  echo "remove Setup:/Network/Service/$OLD_PSID/DNSold" | /usr/sbin/scutil >/dev/null 2>&1 ;
	  echo "remove State:/Network/Service/$OLD_PSID/DNSold" | /usr/sbin/scutil >/dev/null 2>&1 ;
	  echo "remove State:/Network/Global/DNSold" | /usr/sbin/scutil >/dev/null 2>&1 ;
      fi

      # Check if we need to remove the route we added for the DNS
      if [ "$traffic_is_redirected" == "1" ] && [ "$route_net_gateway" != "`GetActualDNS $OLD_PSID`" ] && [ "$route_net_gateway" != "" ] && [ "`GetActualDNS $OLD_PSID`" != "" ] ; then
 	  echo "Removing route to `GetActualDNS $OLD_PSID` with gateway $route_net_gateway" 
	  /sbin/route delete -net `GetActualDNS $OLD_PSID` $route_net_gateway 255.255.255.255 
      fi

      # Remove informations about the connection
      echo "remove State:/Network/Service/OpenVPN/DNS" | /usr/sbin/scutil >/dev/null 2>&1
      echo "remove State:/Network/Service/OpenVPN/IPv4" | /usr/sbin/scutil >/dev/null 2>&1
      echo "remove State:/Network/Service/OpenVPN/PPP" | /usr/sbin/scutil >/dev/null 2>&1
      echo "remove State:/Network/Service/OpenVPN/PSID" | /usr/sbin/scutil >/dev/null 2>&1

      echo "remove Setup:/Network/Service/OpenVPN/IPv4" | /usr/sbin/scutil >/dev/null 2>&1
      echo "remove Setup:/Network/Service/OpenVPN/PPP" | /usr/sbin/scutil >/dev/null 2>&1
      echo "remove Setup:/Network/Service/OpenVPN/Interface" | /usr/sbin/scutil >/dev/null 2>&1
   ;;
   *) echo "$0: invalid script_type $script_type" && exit 1 ;;
esac

#####
