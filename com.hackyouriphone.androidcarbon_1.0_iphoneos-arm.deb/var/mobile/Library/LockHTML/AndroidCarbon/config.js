var MainColor = "White";
var DayColor = "linear-gradient(to right, #7474bf, #348ac7)";
var FooterColor = "Black";
var HeaderBackground = "linear-gradient(to right, #7474bf, #348ac7)";
var LightIcons = true;
var HideLine = false;
var Motto = "Look up at the stars and not down at your feet. Try to make sense of what you see, and wonder about what makes the universe exist. Be curious.";
var ZoomLevel = 80;
