var shapeName = "Icosahedron";
var mode = "normal";
var color = "#FFFFFF";

var inertia = 0.05;

var scale = 5;
var offsetY = 0;

var ambientSporadic = false;
var ambientConstant = false;

var ambientSporadicTicks = 150;
var ambientSporadicVelocity = 50;

var ambientRotationX = 1;
var ambientRotationY = 1;
