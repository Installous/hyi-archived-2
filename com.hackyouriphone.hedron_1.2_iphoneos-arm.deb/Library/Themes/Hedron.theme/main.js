var scene = new THREE.Scene();
var camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
var renderer = new THREE.WebGLRenderer({alpha:true});
renderer.sortObjects = false;
renderer.setPixelRatio(window.devicePixelRatio ? window.devicePixelRatio : 1)
renderer.setClearColor( 0xffffff, 0);

var ratio = window.innerWidth / window.innerHeight;
var hc = 100 / ratio;
var wc = 100;

var element = document.getElementById('popup');
var mt = offsetY - 0.15*window.innerHeight;
element.setAttribute("style", "margin-top: " + mt + "px");

renderer.setSize( window.innerWidth, window.innerHeight);
document.getElementById("wrapper").appendChild( renderer.domElement );

var geom; 
var mesh; 
var shape;

function pad(num, size) {
    var s = num+"";
    while (s.length < size) s = "0" + s;
    return s;
}

if (mode == "normal") {
	mesh = new THREE.MeshBasicMaterial(
		{color:parseInt("0x"+color.substr(1)) ,wireframe:true, opacity:1});

	if (shapeName.toLowerCase() === "icosahedron") {
		geom = new THREE.IcosahedronGeometry(1);		
		shape = new THREE.Mesh(geom, mesh);		
	} else if (shapeName.toLowerCase() === "cube") {
		geom = new THREE.BoxGeometry(1,1,1);
		shape = new THREE.Mesh(geom, mesh);
	} else if (shapeName.toLowerCase() === "dodecahedron") {
		geom = new THREE.DodecahedronGeometry();
		shape = new THREE.Mesh(geom, mesh);
	} else if (shapeName.toLowerCase() === "tetrahedron") {
		geom = new THREE.TetrahedronGeometry(); 	
		shape = new THREE.Mesh(geom, mesh);
	} else if (shapeName.toLowerCase() === "torus") {
		geom = new THREE.TorusGeometry( 10, 3, 16, 100 );	
		shape = new THREE.Mesh(geom, mesh);		
	} else if (shapeName.toLowerCase() === "clock") {
		shape = createCubeClock();

	}
	
	
} else if (mode == "edges") {
	var edges;
	mesh = new THREE.MeshBasicMaterial(
			{color:0xffffff, transparent:true, opacity:0});
	
	if (shapeName.toLowerCase() === "icosahedron") {
		geom = new THREE.IcosahedronGeometry(1);		
	} else if (shapeName.toLowerCase() === "cube") {
		geom = new THREE.BoxGeometry(1, 1, 1);
	} else if (shapeName.toLowerCase() === "dodecahedron") {
		geom = new THREE.DodecahedronGeometry();
	} else if (shapeName.toLowerCase() === "tetrahedron") {
		geom = new THREE.TetrahedronGeometry(); 	
	} else if (shapeName.toLowerCase() === "torus") {
		geom = new THREE.TorusGeometry( 5, 3, 8, 50 );		
	}
	shape = new THREE.Mesh(geom, mesh);
	shape.opacity = 0;
	edges = new THREE.EdgesHelper(shape, 0xffffff);
	scene.add(edges);

}

function createCubeClock() {
	var mesh = new THREE.MeshBasicMaterial(
		{color:parseInt("0x"+color.substr(1)) ,wireframe:true, opacity:1});
	var geom = new THREE.BoxGeometry(1, 1, 1);
	var materials = [];

	for (var i=0; i<6; i++) {
		size = 10;
		var canvas = document.createElement("canvas");
		
		var context = canvas.getContext("2d");
		canvas.width = 200;
		canvas.height = 200;
		context.font = 50 + "pt Arial";
		
		context.strokeStyle = "#FFFFFF";
		context.lineWidth = 3;
		context.moveTo(0,0);
		context.lineTo(200, 0);
		context.moveTo(200, 0);
		context.lineTo(200, 200);
		context.moveTo(200, 200);
		context.lineTo(0, 200);
		context.moveTo(0, 200);
		context.lineTo(0, 0);
		context.stroke();
		
		if (i == 4) {
			var d = new Date();
			time = pad(d.getHours(), 2) + ":" + pad(d.getMinutes(), 2);
			context.textAlign = "center";
			context.textBaseline = "middle";
			context.fillStyle = color;
			context.fillText(time, canvas.width / 2, canvas.height / 2);
		}
			var texture = new THREE.Texture(canvas);
			texture.needsUpdate = true;

	  var mat = new THREE.MeshBasicMaterial({color:0xffffff, map: texture, transparent:true});
	  mat.side = THREE.DoubleSide;
	  mat.transparent = true;
	  materials.push(mat);
	}
	var sh = new THREE.Mesh(geom, new THREE.MeshFaceMaterial( materials ));
	return sh;

}

scene.add(shape);

var targetRotation = 0;
var targetRotationOnMouseDown = 0;

var targetRotationY = 0;
var targetRotationOnMouseDownY = 0;

var mouseX = 0;
var mouseXOnMouseDown = 0;

var mouseY = 0;
var mouseYOnMouseDown = 0;

var windowHalfX = window.innerWidth / 2;
var windowHalfY = window.innerHeight / 2;



camera.position.z = scale;

document.addEventListener( 'mousedown', onDocumentMouseDown, false );
document.addEventListener( 'touchstart', onDocumentTouchStart, false );
document.addEventListener( 'touchmove', onDocumentTouchMove, false );

function onDocumentMouseDown( event ) {

	event.preventDefault();

	document.addEventListener( 'mousemove', onDocumentMouseMove, false );
	document.addEventListener( 'mouseup', onDocumentMouseUp, false );
	document.addEventListener( 'mouseout', onDocumentMouseOut, false );

	mouseXOnMouseDown = event.clientX - windowHalfX;
	mouseYOnMouseDown = event.clientY - windowHalfY;
	targetRotationOnMouseDown = targetRotation;
	targetRotationOnMouseDownY = targetRotationY;

}

function onDocumentMouseMove( event ) {

	mouseX = event.clientX - windowHalfX;

	targetRotation = targetRotationOnMouseDown + ( mouseX - mouseXOnMouseDown ) * 0.02;
	
	mouseY = event.clientY - windowHalfY;
	targetRotationY = targetRotationOnMouseDownY + ( mouseX - mouseYOnMouseDown ) * 0.02;

}

function onDocumentMouseUp( event ) {

	document.removeEventListener( 'mousemove', onDocumentMouseMove, false );
	document.removeEventListener( 'mouseup', onDocumentMouseUp, false );
	document.removeEventListener( 'mouseout', onDocumentMouseOut, false );

}

function onDocumentMouseOut( event ) {

	document.removeEventListener( 'mousemove', onDocumentMouseMove, false );
	document.removeEventListener( 'mouseup', onDocumentMouseUp, false );
	document.removeEventListener( 'mouseout', onDocumentMouseOut, false );

}

function onDocumentTouchStart( event ) {
	var my	= event.touches[ 0 ].pageY - windowHalfY;
	if ( event.touches.length === 1 && my <= window.innerHeight-100 ) {

		event.preventDefault();

		mouseXOnMouseDown = event.touches[ 0 ].pageX - windowHalfX;
		mouseYOnMouseDown = event.touches[ 0 ].pageY - windowHalfY;
		targetRotationOnMouseDown = targetRotation;
		targetRotationOnMouseDownY = targetRotationY;

	}

}


function onDocumentTouchMove( event ) {
	var my	= event.touches[ 0 ].pageY - windowHalfY;
	if ( event.touches.length === 1 && my <= window.innerHeight-100 ) {

		event.preventDefault();

		mouseX = event.touches[ 0 ].pageX - windowHalfX;
		mouseY	= event.touches[ 0 ].pageY - windowHalfY;
		targetRotation = targetRotationOnMouseDown + ( mouseX - mouseXOnMouseDown ) * 0.05;
		targetRotationY = targetRotationOnMouseDownY + ( mouseY - mouseYOnMouseDown ) * 0.05;
		
	}

}

var rotatephase = 0;
var tick = 0;
var render = function() {
    requestAnimationFrame(render);
	tick ++;
	
	tick = (tick % (ambientSporadicTicks*10));
	
	if (shapeName == "clock" && tick%100 == 0) {
		scene.remove(shape);
		rotx = shape.rotation.x;
		roty = shape.rotation.y;
		shape = createCubeClock();
		shape.rotation.x = rotx;
		shape.rotation.y = roty;
		scene.add(shape);

	}
	
	if (ambientSporadic){
		console.log(tick);
		if (tick % ambientSporadicTicks == 0 ) {
			rotatephase = ambientSporadicVelocity;

		}
		if (rotatephase > 10) {
			shape.rotation.x += ambientSporadicVelocity/rotatephase/100;
			shape.rotation.y += ambientSporadicVelocity/rotatephase/100;
			rotatephase --;

		} else if (rotatephase > 0) {
			shape.rotation.x += rotatephase/ambientSporadicVelocity/98;
			shape.rotation.y += rotatephase/ambientSporadicVelocity/98;
			rotatephase --;

		}
	} else if (ambientConstant) {
		shape.rotation.y += ambientRotationY/100;
		shape.rotation.x += ambientRotationX/100;

	} else {
		shape.rotation.y += ( targetRotation - shape.rotation.y ) * inertia;
		shape.rotation.x += ( targetRotationY - shape.rotation.x ) * inertia;
	}
	
	
    renderer.render(scene, camera);
}
// calling the function
render();