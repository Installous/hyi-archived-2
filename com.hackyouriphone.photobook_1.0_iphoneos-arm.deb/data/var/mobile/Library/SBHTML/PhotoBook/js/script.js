/**
 * Author: Vinayak Rangnathrao Jadhav
 * Project: jR3DCarousel
 * Version: 1.0.5
 **/
(function(b) {
    "function" === typeof define && define.amd ? define(["jquery"], b) : "object" === typeof exports ? module.exports = b(require("jquery")) : b(jQuery)
})(function(b) {
    b.fn.jR3DCarousel = function(E) {
        function x() {
            q();
            v = setInterval(A, a.animationInterval + a.animationDuration)
        }

        function q() {
            v && clearInterval(v)
        }

        function A() {
            r = u + 1;
            y.run(a.animation, r);
            z()
        }

        function B(F) {
            r = Math.floor(u / c) * c + F;
            y.run(a.animation, r);
            z()
        }

        function w() {
            this.animations = {
                slide: G,
                slide3D: H,
                scroll: I,
                scroll3D: J,
                fade: K
            }
        }

        function G(a) {
            d.css({
                perspective: "",
                overflow: "hidden"
            });
            f = g * a;
            h.css({
                transform: "translateZ(" + -e + "px) rotateY(" + -f + "deg)"
            })
        }

        function H(a) {
            d.css({
                perspective: k,
                overflow: "visible"
            });
            f = g * a;
            h.css({
                transform: "translateZ(" + -e + "px) rotateY(" + -f + "deg)"
            })
        }

        function I(a) {
            d.css({
                perspective: "",
                overflow: "hidden"
            });
            f = g * a;
            h.css({
                transform: "translateZ(" + -e + "px) rotateX(" + -f + "deg)"
            })
        }

        function J(a) {
            d.css({
                perspective: k,
                overflow: "visible"
            });
            f = g * a;
            h.css({
                transform: "translateZ(" + -e + "px) rotateX(" + -f + "deg)"
            })
        }

        function K(d) {
            h.css({
                transition: "opacity " + a.animationDuration +
                    "ms " + a.animationCurve,
                opacity: 0
            });
            f = g * d;
            h.css({
                transform: "translateZ(" + -e + "px) rotateY(" + -f + "deg)"
            });
            h.css({
                opacity: 1
            })
        }

        function z() {
            d.find(".nav").css({
                backgroundColor: "rgba(255, 255, 255, 0.77)"
            }).eq(r % c).css({
                backgroundColor: "rgba(0, 0, 0, 0.77)"
            });
            u = Math.round(f / g);
            a.onSlideShow.call(this, h.find("." + a.slideClass).eq(u % c))
        }

        function C() {
            d.width("100%");
            h.hide();
            n = d.width() < a.width ? d.width() : a.width;
            t = n / L;
            d.css({
                width: n + "px",
                height: t + "px"
            }); - 1 != a.animation.indexOf("slide") ? (e = n / 2 / Math.tan(Math.PI /
                c), k = n / 2 * Math.tan(2 * Math.PI / c) + "px") : -1 != a.animation.indexOf("scroll") ? (e = t / 2 / Math.tan(Math.PI / c), k = t / 2 * Math.tan(2 * Math.PI / c) + "px") : "fade" == a.animation && (e = n / 2 / Math.tan(Math.PI / c), k = n / 2 * Math.tan(2 * Math.PI / c) + "px");
            d.find("." + a.slideClass).each(function(d) {
                var c = b(this); - 1 != a.animation.indexOf("slide") ? p = "rotateY(" + g * d + "deg) translateZ(" + e + "px)" : -1 != a.animation.indexOf("scroll") ? p = "rotateX(" + g * d + "deg) translateZ(" + e + "px)" : "fade" == a.animation && (p = "rotateY(" + g * d + "deg) translateZ(" + e + "px)");
                c.css({
                    transform: p
                })
            });
            k = a.perspective || k;
            h.css({
                transform: "translateZ(" + -e + "px) rotateY(" + -f + "deg)"
            });
            h.show();
            d.css({
                perspective: k
            })
        }


        var a = b.extend(!0, {}, {
                width: innerWidth,
                height: innerHeight,
                slides: [],
                slideLayout: "fill",
                perspective: 0,
                animation: "slide3D",
                animationCurve: "ease",
                animationDuration: TimeToAnimate * 1000,
                animationInterval: ShowFor * 1000,
                autoplay: !0,
                controls: !0,
                slideClass: "jR3DCarouselSlide",
                navigation: "circles",
                rotationDirection: "rtl",
                onSlideShow: function() {}
            }, E),
            d = this,
            n = a.width,
            t = a.height,
            L = a.width / a.height,
            h = b("<div class='jR3DCarousel' />").css({
                width: "100%",
                height: "100%",
                transition: "transform " +
                    a.animationDuration + "ms " + a.animationCurve,
                transformStyle: "preserve-3d"
            }).appendTo(d),
            u = 0,
            r = 1,
            y = new w,
            l, m, v, g, f = 0,
            e, k, p, c = a.slides.length || d.find("." + a.slideClass).length;
        (function() {
            function f() {
                "rtl" == a.rotationDirection ? (l = b("<div class='previous controls' style='left: 0.1em;'>&lang;</div>"), m = b("<div class='next controls' style='right: 0.1em;'>&rang;</div>")) : (l = b("<div class='previous controls' style='right: 0.1em;'>&rang;</div>"), m = b("<div class='next controls' style='left: 0.1em;'>&lang;</div>"));
                l.add(m).css({
                    position: "absolute",
                    top: "50%",
                    zIndex: 1,
                    transform: "translateY(-50%)",
                    fontSize: "4em",
                    color: "rgba(255, 255, 255, 0.97)",
                    cursor: "pointer",
                    userSelect: "none"
                }).appendTo(d).hide();
            }

            function v() {
                for (var e = b("<div class=navigation />").css({
                        position: "absolute",
                        bottom: 0,
                        right: 0
                    }), g = 0; g < c; g++) e.append("<div class=nav></div>");
                "circles" == a.navigation && e.find(".nav").css({
                    borderRadius: "12px"
                });
                e.find(".nav").css({
                    display: "inline-block",
                    margin: "5px",
                    cursor: "pointer",
                    backgroundColor: "rgba(255, 255, 255, 0.77)",
                    width: "12px",
                    height: "12px",
                    transition: "all " + a.animationDuration +
                        "ms ease"
                }).first().css({
                    backgroundColor: "rgba(0, 0, 0, 1)"
                });
                h.after(e);
                //d.on("click", ".nav", function() {
               //     B(b(this).index())
                //})
            }(function() {
                -1 != a.animation.indexOf("slide") ? (e = n / 2 / Math.tan(Math.PI / c), k = n / 2 * Math.tan(2 * Math.PI / c) + "px") : -1 != a.animation.indexOf("scroll") ? (e = t / 2 / Math.tan(Math.PI / c), k = t / 2 * Math.tan(2 * Math.PI / c) + "px") : "fade" == a.animation && (e = n / 2 / Math.tan(Math.PI / c), k = n / 2 * Math.tan(2 * Math.PI / c) + "px");
                g = 360 / c;
                if (a.slides.length)
                    for (var f = 0; f < a.slides.length; f++) {
                        var l = b("<div class='jR3DCarouselSlide' data-index=" +
                            f + " />").append("<img src='" + a.slides[f].src + "' alt='" + a.slides[f].alt + "' />"); - 1 != a.animation.indexOf("slide") ? p = "rotateY(" + g * f + "deg) translateZ(" + e + "px)" : -1 != a.animation.indexOf("scroll") ? p = "rotateX(" + g * f + "deg) translateZ(" + e + "px)" : "fade" == a.animation && (p = "rotateY(" + g * f + "deg) translateZ(" + e + "px)");
                        l.css({
                            transform: p
                        });
                        h.append(l)
                    } else d.find("." + a.slideClass).each(function(c) {
                        var d = b(this).attr("data-index", c); - 1 != a.animation.indexOf("slide") ? p = "rotateY(" + g * c + "deg) translateZ(" + e + "px)" : -1 != a.animation.indexOf("scroll") ?
                            p = "rotateX(" + g * c + "deg) translateZ(" + e + "px)" : "fade" == a.animation && (p = "rotateY(" + g * c + "deg) translateZ(" + e + "px)");
                        d = d.css({
                            transform: p
                        }).detach();
                        h.append(d)
                    });
                h.find("." + a.slideClass).css({
                    position: "absolute",
                    left: 0,
                    top: 0,
                    width: "100%",
                    height: "100%",
                    backfaceVisibility: "hidden"
                }).find("img").css({
                    width: "100%",
                    height: "100%",
                    objectFit: a.slideLayout
                });
                k = a.perspective || k;
                d.css({
                    perspective: k,
                    width: n + "px",
                    height: t + "px",
                    position: "relative",
                    overflow: "visible"
                })
            })();
            a.controls && f();
            a.navigation && v();
            addEventListener("resize",
                C);
            C();
            if (a.autoplay) {
                var w = function() {
                    document.hidden ? q() : x()
                };
                document.addEventListener("visibilitychange", w);
                addEventListener("beforeunload", function() {
                    document.removeEventListener("visibilitychange", w)
                });
                x()
            }
        })();
        w.prototype.run = function(a, b) {
            this.animations[a](b)
        };
        this.showSlide = function(a) {
            B(a % c)
        };
        this.getCurrentSlide = function() {
            return h.find("." +
                a.slideClass).eq(u % c)
        };
        this.getSlideByIndex = function(b) {
            return h.find("." + a.slideClass + "[data-index=" + b + "]")
        };
        this.showPreviousSlide = function() {
            l.click()
        };
        this.showNextSlide = function() {
            m.click()
        };
        this.playCarousel = function() {
            x()
        };
        this.pauseCarousel = function() {
            q()
        };
        return this
    }
});
