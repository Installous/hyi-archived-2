@interface UIScreen ()
- (CGRect)_referenceBounds; // static values for iOS8+
- (CGRect)_realDisplayBounds; // static values for iOS7 requires / scale (!)
@end

@interface SBHUDView : UIView
@end

@interface SBVolumeHUDView : UIView
@end

@interface VolumeControl : NSObject
+ (id)sharedVolumeControl;
- (float)volume;
- (void)_changeVolumeBy: (float)arg1;	
@end

@interface AVSystemController
+ (AVSystemController*)sharedAVSystemController;
- (BOOL)setVolumeTo: (float)volume forCategory: (NSString*)category;
- (BOOL)getVolume: (float*)volume forCategory: (NSString*)category;
@end

@interface UIApplication ()
- (long long)activeInterfaceOrientation;
- (UIView *)statusBar;
- (float)backlightLevel;
@end

@interface SBApplication : NSObject
- (int)statusBarStyle;
- (BOOL)statusBarHiddenForCurrentOrientation;
@end

@interface SpringBoard : UIApplication
- (SBApplication *)_accessibilityFrontMostApplication;
@end

@interface SBIconController : UIViewController
+ (id)sharedInstance;
- (id)dockListView;
- (BOOL)hasOpenFolder;
@end

@interface SBLockScreenManager : NSObject
-(void)unlockUIFromSource:(int)arg1 withOptions:(id)arg2;
-(BOOL)isUILocked;
@end

@interface SBBacklightController : NSObject
-(BOOL)screenIsOff;
-(BOOL)screenIsOn;
@end

@interface SBHUDController : NSObject
+ (id)sharedHUDController;
@end

@interface UIStatusBarServer : NSObject
+(void)postStatusBarData:(void *)data withActions:(int)actions;
+(void*)getStatusBarData;
@end 

@interface SBMainStatusBarStateProvider
+(id)sharedInstance;
-(void)setTimeCloaked:(BOOL)arg1 ;
@end

@interface UIImage ()
+ (id)imageNamed: (id)named inBundle: (id)bundle;
@end

@interface UIImage (colorize)
+ (UIImage *)fillImage: (UIImage *)source withColor: (UIColor *)color;
@end


@interface _UIBackdropView : UIView  
-(void)transitionToColor:(id)arg1 ;
@end

@interface UIButton()
-(void)_setImageColor:(id)arg1 forState:(unsigned long long)arg2 ;
@end

@interface SBBrightnessController : NSObject
+(id)sharedBrightnessController;
-(void)setBrightnessLevel:(float)arg1;
@end


@interface SBUIChevronView : UIView
-(void)setColor:(UIColor *)color;
-(void)setState:(long long)arg1;
@end