/*
Configuration here !
Done by Dacal - Modded by Dino97400 // don't remove this line motherfucker //
For weather code, go to http://weather.yahoo.com/ and search for your city. The correct zip code is in the URL (only numbers)
*/


var iconSet = "Outlined"		 // add your own set
