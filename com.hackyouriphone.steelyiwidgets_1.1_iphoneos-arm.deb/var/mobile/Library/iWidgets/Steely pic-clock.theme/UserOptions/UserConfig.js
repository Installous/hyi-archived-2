/* *************************************** */
/* The following scripts will allow you to finetune */

/* *************************************** */

/* Minutes between updates */
var updateInterval = 15


/* ****************************************************** */
