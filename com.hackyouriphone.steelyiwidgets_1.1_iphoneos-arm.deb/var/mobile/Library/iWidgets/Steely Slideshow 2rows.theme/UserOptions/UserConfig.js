/* *************** Slideshow widget Belgmeister ************************ */
/* *************** Flux slider by Joe Lambert   ************************ */

 /*
 
 Available Transitions

'blocks2', 
'tiles3d',
'bars', 
'zip',
'blinds', 
'blocks',
'concentric', 
'warp', 
'slide', 
'dissolve',
'bars3d',
'cube',
'blinds3d', 
'turn',


Change the images in Private/Images.
prefferably make them 330px x 206px for optimal performance
*/