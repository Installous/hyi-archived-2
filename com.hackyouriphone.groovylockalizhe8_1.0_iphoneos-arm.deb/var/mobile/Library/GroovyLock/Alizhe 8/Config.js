var Locale= "USMS0365"; //weather code. Find from weather.com look in url
var Celsius = false; // turn on for Celsius
var TwentyFourHour = false; // use 24hr clock
var Kph = false; // Use kph instead of mph
var Forecast = true; // turn forecast on/off
var TODWallpaper=true; //turn off TOD wallpaper