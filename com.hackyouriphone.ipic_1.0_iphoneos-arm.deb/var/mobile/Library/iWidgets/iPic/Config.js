var Scale = "0.8"; 
var Clock = "12h"; // choose between "12h" or "24h"
var Shape = "1"; // 1-10 template shape
var TextColor1 = "azure"; 
var TextColor2 = "silver"; 
var ShadowColor = "black"; 
