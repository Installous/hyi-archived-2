var refresh = 6868; 
var language = "en"; 
var padzero = false; 
var twentyfourhour = true; 
