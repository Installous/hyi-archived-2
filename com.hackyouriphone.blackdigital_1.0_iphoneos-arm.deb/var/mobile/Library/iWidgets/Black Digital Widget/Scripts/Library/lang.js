var language, 
weekday, 
month, 
smonth, 
sday
//language="en";// tester

     var charging = " charging";
     var discharging = " discharging";

if (language === "en") {

    sday = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

    month = ["01", "02", "03", "04", "05", "06", "07", "08","09", "10", "1 1", "12"];

    smonth = ["01", "02", "03", 
    "04", "05", "06", "07", "08",
     "09", "10", "1 1", "12"];

    weekday = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

}