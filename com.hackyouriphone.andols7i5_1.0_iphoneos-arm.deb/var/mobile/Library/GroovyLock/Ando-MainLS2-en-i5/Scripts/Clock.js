
function updateClock ( )
{
if (Clock == "24h") {

  var currentTime = new Date ( );
  var currentHours = currentTime.getHours ( );
  var currentMinutes = currentTime.getMinutes ( );
  var currentSeconds = currentTime.getSeconds ( );

  var previousHours = currentHours -1;
  var nextMinutes = currentMinutes +1;
  var previous2Hours = currentHours -2;
  var next2Minutes = currentMinutes +2;

  // Pad the minutes and seconds with leading zeros, if required

  previousHours = ( previousHours == -1 ) ? "23" : previousHours;
  previous2Hours = ( previous2Hours == -1 ) ? "23" : previous2Hours;
  previous2Hours = ( previous2Hours == -2 ) ? "22" : previous2Hours;
  currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
  currentSeconds = ( currentSeconds < 10 ? "0" : "" ) + currentSeconds;
  currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;
  
  previousHours = ( previousHours < 10 ? "0" : "" ) + previousHours;
  previous2Hours = ( previous2Hours < 10 ? "0" : "" ) + previous2Hours;
  nextMinutes = ( nextMinutes < 10 ? "0" : "" ) + nextMinutes; 
  next2Minutes = ( next2Minutes < 10 ? "0" : "" ) + next2Minutes; 

  nextMinutes = ( nextMinutes  == 60 ) ? "00" : nextMinutes;
  next2Minutes = ( next2Minutes  == 60 ) ? "00" : next2Minutes;
  next2Minutes = ( next2Minutes  == 61 ) ? "01" : next2Minutes;
}
if (Clock == "12h") {
  
  var currentTime = new Date ( );
  var currentHours = currentTime.getHours ( );
  var currentMinutes = currentTime.getMinutes ( );
  var currentSeconds = currentTime.getSeconds ( );

  var previousHours = currentHours -1;
  var nextMinutes = currentMinutes +1;
  var previous2Hours = currentHours -2;
  var next2Minutes = currentMinutes +2;

  // Pad the minutes and seconds with leading zeros, if required

  var timeOfDay = ( currentHours < 12 ) ? "AM" : "PM";
  previousHours = ( previousHours == -1 ) ? "59" : previousHours;
  previous2Hours = ( previous2Hours == -1 ) ? "59" : previous2Hours;
  previous2Hours = ( previous2Hours == -2 ) ? "58" : previous2Hours;
  currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
  currentHours = ( currentHours == 0 ) ? 12 : currentHours;
  currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
  currentSeconds = ( currentSeconds < 10 ? "0" : "" ) + currentSeconds;
  currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;
  
  previousHours = ( previousHours > 12 ) ? previousHours - 12 : previousHours;
  previousHours = ( previousHours == 0 ) ? 12 : previousHours;
  previous2Hours = ( previous2Hours > 12 ) ? previous2Hours - 12 : previous2Hours;
  previous2Hours = ( previous2Hours == 0 ) ? 12 : previous2Hours;
  previousHours = ( previousHours < 10 ? "0" : "" ) + previousHours;
  previous2Hours = ( previous2Hours < 10 ? "0" : "" ) + previous2Hours;
  nextMinutes = ( nextMinutes < 10 ? "0" : "" ) + nextMinutes; 
  next2Minutes = ( next2Minutes < 10 ? "0" : "" ) + next2Minutes; 

  nextMinutes = ( nextMinutes  == 60 ) ? "00" : nextMinutes;
  next2Minutes = ( next2Minutes  == 60 ) ? "00" : next2Minutes;
  next2Minutes = ( next2Minutes  == 61 ) ? "01" : next2Minutes;
}

var currentTimeString = currentHours;
var currentTimeString1 = currentMinutes;
var previousTimeString = previousHours;
var nextTimeString = nextMinutes;
var previous2TimeString = previous2Hours;
var next2TimeString = next2Minutes;

document.getElementById("prevhour1").innerHTML = previous2TimeString;
document.getElementById("prevhour").innerHTML = previousTimeString;
document.getElementById("hours").innerHTML = currentTimeString;
document.getElementById("mins").innerHTML = currentTimeString1;
document.getElementById("nextmin").innerHTML = nextTimeString;
document.getElementById("nextmin1").innerHTML = next2TimeString;
}