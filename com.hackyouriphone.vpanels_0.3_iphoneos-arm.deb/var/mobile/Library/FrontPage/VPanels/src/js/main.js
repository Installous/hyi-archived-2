function getComputed(el, styleName) {
    var element = document.querySelector(el),
    	style, styleValue;
    	if(!element){
    		element = document.getElementById(el);
    	}
        style = window.getComputedStyle(element),
        styleValue = style.getPropertyValue(styleName);
    return parseInt(styleValue);
}

function loadPanelApps(){
	var iconArray = lStorage.iconHolderBundles, //apps to load
		iconHolder = document.getElementById('card3'),
		icon, badge, i, grid, iconWidth, topGap, leftGap;
		
	iconHolder.innerHTML = '<div id="infobutton" onclick="infoClicked()">P</div>'; //clear container

	iconWidth = 45;
	topGap = 25;
	leftGap = 15;

	//iP5
	if(window.innerWidth === 320 && window.innerHeight === 568){
		iconWidth = 35;
		topGap = 20;
		leftGap = 15;
	}

	grid = gridMaker({
        itemCount: iconArray.length,
        itemWidth: iconWidth,
        holderWidth: getComputed('card3', 'width'),
        holderHeight: getComputed('card3', 'height'),
        leftGap: leftGap,
        topGap: topGap,
        topOffset: 0
    });

	for (i = 0; i < iconArray.length; i++) {
		//create icon
		icon = createDOM({
	        type: 'div',
	        className: 'icon',
	        id: iconArray[i]
	    });

	    icon.title = getIconName(iconArray[i]);
		
		icon.style.top = grid[i].top + "px";
		icon.style.left = grid[i].left + "px";
		icon.style.width = grid[i].width + "px";
		icon.style.height = grid[i].width + "px";

	    //create badge
	    badge = createDOM({
	        type: 'div',
	        className: 'badge',
	        innerHTML: getIconBadge(iconArray[i]),
	        id: iconArray[i] + 'badge'
	    });

	    badge.style.marginLeft = grid[i].width - 10 + "px";

	    /*
	    	if badge is set then change the width, padding and set text
	    	color to transparent
	    */
	    if(lStorage.badgeImage){
	    	badge.style.backgroundImage = "url('" + lStorage.badgeImage + "')";
	    	badge.style.width = "15px";
	    	badge.style.padding = "0px";
	    	badge.style.color = 'transparent';
	    }else{
	    	badge.style.backgroundImage = "";
	    	badge.style.width = "auto";
	    	badge.style.padding = "0 6px";
	    	badge.color = (lStorage.badgetextcolor) ? lStorage.badgetextcolor : 'white';

	    }
	    //append badge to the icon
	    icon.appendChild(badge);
	    setIconImage(icon, iconArray[i]);

	    //set icon image
	    //icon.style.backgroundImage = "url('" + getIconImage(iconArray[i]) + "')";
		
		//append icon to icon holder
		iconHolder.appendChild(icon);
	}
}