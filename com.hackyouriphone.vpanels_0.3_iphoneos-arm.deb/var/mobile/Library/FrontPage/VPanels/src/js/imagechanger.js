var imageSelector = document.getElementById('imageSelector');

function deleteImage(divName){
  if(localStorage[divName]){
    location.href = 'frontpage:deleteImage:' + localStorage[divName];
  }
  localStorage.removeItem(divName);
}

function picChanged() {
    var file = imageSelector.files[0];
    location.href = 'frontpage:moveImage:' + file.name;

    setTimeout(function(){
      var divel = globalVars.changedImage;
      document.getElementById(divel).style.backgroundImage = "linear-gradient(rgba(0, 0, 0, 0.4),rgba(0, 0, 0, 0.4)),url(file:///var/mobile/Documents/FrontPageImages/" + file.name + ")";
      setTimeout(function(){
        deleteImage(divel);
      localStorage[divel] = file.name;
      },1000);
    },1000);

}

if(localStorage.card1){
  document.getElementById('card1').style.backgroundImage = "linear-gradient(rgba(0, 0, 0, 0.4),rgba(0, 0, 0, 0.4)),url(file:///var/mobile/Documents/FrontPageImages/" + localStorage.card1 + ")";
}
if(localStorage.card2){
  document.getElementById('card2').style.backgroundImage = "linear-gradient(rgba(0, 0, 0, 0.4),rgba(0, 0, 0, 0.4)),url(file:///var/mobile/Documents/FrontPageImages/" + localStorage.card2 + ")";
}


imageSelector.addEventListener('change', picChanged, false);