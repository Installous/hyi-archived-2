
function infoClicked(){
	var container = doc.getElementById('card3');
	container.className = "card3 settingsopen";
    jSettings.openSettings();
}

(function(doc){
	var drawer = doc.getElementById('drawer'),
		container = doc.getElementById('card3');

	/* 
		Set class of container to just container
		so we know that settings aren't opened.

		Close settings
	*/
	function closeSettings(){
		container.className = "card3";
		jSettings.closeSettings();
        jSettings.closeSettingsMenus();
        jSettings.closeColorPickers();
	}

	/* Close settings if opened then open drawer */
	function openDrawer(){
		closeSettings();
		Drawer.toggleDrawer();
	}

	function animateIcon(on, bundle){
	  if(bundle){
	    var grow = 1.2,
	        standard = 1.0,
	        divEl = document.getElementById(bundle);
	    divEl.style.transition = 'transform 0.2s ease-in-out';
	    if(on){
	        divEl.style.webkitTransform = "scale(" + grow + ")";
	    }else{
	        divEl.style.webkitTransform = "scale(" + standard + ")";
	    }
	  }
	}

	/* cancel open if moved */
	function cancelOpen(){
		globalVars.movedWhilePressing = true;
	}

	/* Animate app on touchstart pressed */
	function animateApp(el){
		if(el.target.id && el.target.className == 'icon' && !globalVars.changingIconImage && !globalVars.movedWhilePressing){
			animateIcon(true, el.target.id);
		}
	}

	/* check if element has an id and user is not changing icons */
	function openApp(el){
		if(el.target.id && !globalVars.changingIconImage && !globalVars.movedWhilePressing){
			window.location = 'frontpage:openApp:' + el.target.id;
		}
		if(el.target.className === 'icon'){
			setTimeout(function(){
				animateIcon(false, el.target.id);
			},100);
		}
		globalVars.movedWhilePressing = false;
	}

	/* If tap hold is triggered then user is trying to change an app or icon */
	function tapHoldOnIcon(element){
		globalVars.changingIconImage = true;
        jPopup({
            type: "confirm",
            message: "Change icon or app?",
            yesButtonText: "Icon",
            noButtonText: "App",
            functionOnNo: function() {
                globalVars.changingIconImage = false;
                globalVars.changingIconDiv = element;
		        Drawer.toggleDrawer({
		            state: 'changingApp',
		            callback: function(newApp) {
		                lStorage.replaceInAppArray('iconHolderBundles', element.id, newApp);
		                loadPanelApps();
		            }
		        });
            },
            functionOnOk: function() {
                globalVars.changingIconDiv = element;
                window.location = 'frontpage:loadIconBrowser';
            }
        });
	}

	function openMusic(){
		var musicbutton = document.getElementById('musicbutton'),
			forecastContainer = document.getElementById('forecastContainer'),
			musicControls = document.getElementById('musicControls'),
			screenWidth = window.innerWidth;

		if(musicbutton.innerHTML === 'd'){
			forecastContainer.style.webkitTransform = "translate(-"+screenWidth+"px, -50%)";
			musicControls.style.webkitTransform = "translate(-50%, -50%)";
			musicbutton.innerHTML = 'S';
		}else{
			forecastContainer.style.webkitTransform = "translate(0px, -50%)";
			musicControls.style.webkitTransform = "translate(100%, -50%)";
			musicbutton.innerHTML = 'd';
		}
	}

	function doMusic(el){
		var button = el.target.id;
		if(button === 'play'){
			window.location = 'frontpage:playmusic';
		}else if (button === 'next'){
			window.location = 'frontpage:nexttrack';
		}else if (button === 'prev'){
			window.location = 'frontpage:prevtrack';
		}
	}
	function openSearch(){
		window.location = 'frontpage:opensearch';
	}

	/* 
		Add multiple tap on the container div to open settings.
	*/
	multipleTap({
        div: container,
        taps:3,
        callback: function(){
        	container.className = "card3 settingsopen";
            jSettings.openSettings();
        }
    });

	/*
		Listen for clicks if element clicked has a class of
		container and settingsopen then close settings.
	*/
    container.addEventListener('click', function(el) {
	    if (el.target.className === 'card3 settingsopen') {
	        closeSettings();
	    }
	});

    /*
		Add tap hold on container. This is for changing apps of icons of apps
    */
	taphold({
        time: 1000,
        element: doc.getElementById('card3'),
        action: function(element) {
            tapHoldOnIcon(element);
        },
        passTarget: true
    });

	/* Open Drawer */
	drawer.addEventListener('touchstart', openDrawer, false);
	/* Open App */
	container.addEventListener('touchend', openApp, false);
	container.addEventListener('touchstart', animateApp, false);
	container.addEventListener('touchmove', cancelOpen, false);
	document.getElementById('musicbutton').addEventListener('touchstart', openMusic, false);
	document.getElementById('controls').addEventListener('touchstart', doMusic, false);
	document.getElementById('searchbutton').addEventListener('touchstart', openSearch, false);



	taphold({
        time: 400,
        element: document.getElementById('card1'),
        action: function(target) {
            jPopup({
                type: "confirm",
                message: "Do you wish to replace this image or reset it to default?",
                yesButtonText: "Change",
                noButtonText: "Reset",
                functionOnNo: function() {
                    document.getElementById('card1').style.backgroundImage = "url('defaultimages/1.jpg')";
                    setTimeout(function(){
                        deleteImage('card1');
                    },1000);
                },
                functionOnOk: function() {
                    globalVars.changedImage = target.id;
                    document.getElementById('imageSelector').click();
                }
            });
        },
        passTarget: true
    });
    taphold({
        time: 400,
        element: document.getElementById('card2'),
        action: function(target) {
            jPopup({
                type: "confirm",
                message: "Do you wish to replace this image or reset it to default?",
                yesButtonText: "Change",
                noButtonText: "Reset",
                functionOnNo: function() {
                    document.getElementById('card2').style.backgroundImage = "url('defaultimages/2.jpg')";
                    setTimeout(function(){
                        deleteImage('card2');
                    },1000);
                },
                functionOnOk: function() {
                    globalVars.changedImage = target.id;
                    document.getElementById('imageSelector').click();
                }
            });
        },
        passTarget: true
    });
}(document));