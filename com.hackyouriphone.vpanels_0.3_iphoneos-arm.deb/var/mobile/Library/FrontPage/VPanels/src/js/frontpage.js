/* global globalVars Drawer macDock lStorage getIconInfo translate current clock desktopIcons*/
var FPI = {},
    doc = document;

function createDrawer() {
    var iconW = 11,
        iconM = 25,
        pagingAmount = 20;
    // iPhone X
    if (window.innerHeight == 812) {
        iconW = 12;
        iconM = 15;
        pagingAmount = 32;
    }
    // iPhone XS Max / XR
    if (window.innerHeight == 896) {
        iconW = 12;
        iconM = 15;
        pagingAmount = 32;
    }
    // iPhone 7
    if (window.innerHeight == 667) {
        iconW = 11;
        iconM = 23;
        pagingAmount = 20;
    }
    // iPhone 5, 5s, SE
    if (window.innerHeight == 568) {
        iconW = 10;
        iconM = 20;
        pagingAmount = 20;
    }
    // iPhone 6S+
    if (window.innerHeight == 736) {
        iconW = 12;
        iconM = 15;
        pagingAmount = 32;
    }
    FPI.drawer = new Drawer({
        labels: true,
        idPrefix: "APP",
        pagingAmount: pagingAmount,
        iconWidth: iconW,
        iconMargin: iconM,
        pageSpacing: 20,
        pagePadding: 10,
        labelTopPadding: 1,
    });
}

function setFPIInfo(info, label, parse) {
    if (parse) {
        FPI[label] = JSON.parse(info);
    } else {
        FPI[label] = info;
    }
}

function appsInstalled() {
    FPI.drawer.reloadIcons();
}

function badgeUpdated(bundle) {
    Drawer.updateBadge(bundle);
    var element = document.getElementById(bundle + 'badge');
    if (typeof(element) != 'undefined' && element != null) {
        element.innerHTML = getIconBadge(bundle);
    }
}

function deviceUnlocked() {
    FPI.system["unlocked"] = "yes";
}

function selectedImageFromFP(img) {
    if(globalVars.changingBadgeImage){
        globalVars.changingBadgeImage = false;
        lStorage.badgeImage = img;
    }else{
        lStorage.replaceIconLocation('iconImageLocations', globalVars.changingIconDiv.id, img);
        globalVars.changingIconDiv.style.backgroundImage = "url('" + img + "')";
        globalVars.changingIconImage = false;
    }
    lStorage.saveStorage();
    loadCWApps();
}

function selectedImageFromFPCancelled() {
    globalVars.changingIconImage = false;
    globalVars.changingBadgeImage = false;
}


function loadWeather() {
    var weather = FPI.weather;
    document.getElementById('condition').innerHTML = translate[current].condition[weather.conditionCode] + " " + weather.temperature + "&deg;";
    for (var i = 0; i < forecastDayCount; i++) {
        var icon = weather.dayForecasts[i].icon;
        var dlow = weather.dayForecasts[i].low;
        var dhigh = weather.dayForecasts[i].high;
        var dofw = weather.dayForecasts[i].dayOfWeek - 1;
        icon = (weather.dayForecasts[i].icon == 3200) ? weather.conditionCode : weather.dayForecasts[i].icon;
        document.getElementById('weatherIcons' + i).src = 'src/icons/' + icon + '.png';
        document.getElementById('weatherDays' + i).innerHTML = translate[current].sday[dofw];
        document.getElementById('weatherTemps' + i).innerHTML = dhigh + '&deg;' + '/' + dlow + '&deg;';
    }
    document.getElementById('high').innerHTML = weather.high + "&deg;";
    document.getElementById('low').innerHTML = weather.low + "&deg;";
    document.getElementById('icon').style.backgroundImage = 'url("src/icons/' + weather.conditionCode + '.png")';
}

function loadBattery() {
    document.getElementById('battery').innerHTML = FPI.battery.percent + "%";
}
function loadClock() {
    clock({
        twentyfour: (FPI.system.twentyfour == "yes") ? true : false,
        padzero: true,
        refresh: 5000,
        success: function(clock) {
            document.getElementById('date').innerHTML = translate[current].sday[clock.day()] + " " + clock.dateplus();
            document.getElementById('clock').innerHTML = clock.hour() + ":" + clock.minute();
        }
    });
}

function FPIloaded() {
    loadClock();
    createDrawer();
    loadPanelApps();
}

function todayDismissed(){
    document.body.style.opacity = 1;
}
function loadSystem() {}
function loadFolders() {}
function loadAlarms() {}
function loadMemory() {}
function loadStatusBar() {}
function loadApps() {}
function loadMusic() {
    var innerVar;
    if (FPI.music.isPlaying) {
        innerVar = "t";
        document.getElementById('title').innerHTML = (FPI.music.title != '(null)') ? FPI.music.title : "";
        document.getElementById('artist').innerHTML = (FPI.music.artist != '(null)') ? FPI.music.artist : "";
    } else {
        innerVar = 'q';
    }
    document.getElementById('play').innerHTML = innerVar;
}
function loadSettings() {}
function deviceLocked() {}
function loadNotifications() {}
function loadSwitcher() {}
function viewRotated(direction) {}