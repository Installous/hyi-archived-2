var forecastMaker = {
 	//forecastMaker.makeForecast({
	// 	holder: document.getElementById('forecast'),
	// 	dayCount: 4, //forecast length
	// 	dayWidth: 70, //holder width
	// 	dayHeight: 60, //holder height
	// 	imgWidth: 35, //image size
	// 	font: 'Montserrat-Light',
	// 	dayTop: 0, //day position from top
	// 	tempBottom: 0, //temp position from bottom
	// 	fontSize: 10, //day text and temp size
	// 	iconURL: 'icons/',
	// 	iconsName: 'weatherIcons',
	// 	daysName: 'weatherDays',
	// 	tempsName: 'weatherTemps',
	// });
    makeForecast: function (obj) {
        var doc = document,
        	innerHolder = document.createElement('div');
        for (var i = 0; i < obj.dayCount; i++) {
            var box = doc.createElement('div'),
                image = doc.createElement('img'),
                days = doc.createElement('span'),
                temps = doc.createElement('span');

            //container for elements
            /*	
            	//doesn't work on iOS10
            	float: left;
				display: flex;
		  		justify-content: center;
		  	*/
            box.style.cssText = "\
					position: relative;\
					width: " + obj.dayWidth + "px;\
					height: " + obj.dayHeight + "px;\
					display:inline-block; \
		  			";
		  	innerHolder.id = 'forecastContainer';

            //image element	
            image.id = obj.iconsName + i;
            image.style.cssText = "\
		  			position:absolute;\
		  			left:50%; \
		  			-webkit-transform:translate(-50%, -50%); \
					top:50%;\
					width: " + obj.imgWidth + "px;\
					";
            image.src = obj.iconURL + (30 + i) + ".png";
            box.appendChild(image);

            //day element
            days.innerHTML = "days";
            days.id = obj.daysName + i;
            days.style.cssText = "\
			    position:absolute;\
					color:" + obj.color +";\
					top:" + obj.dayTop + "px;\
					text-align:center;\
					left:50%; \
		  			-webkit-transform:translate(-50%, 0); \
					width: " + obj.dayWidth + "px;\
					font-size:" + obj.fontSize + "px;\
					font-family:" + obj.font + ";\
					";
            box.appendChild(days);

            //temp element
            temps.innerHTML = "temps";
            temps.id = obj.tempsName + i;
            temps.style.cssText = "\
			    	position:absolute;\
					bottom:" + obj.tempBottom + "px;\
					text-align:center;\
					left:50%; \
		  			-webkit-transform:translate(-50%, 0); \
					width: " + obj.dayWidth + "px;\
					color:" + obj.color +";\
					font-size:" + obj.fontSize + "px;\
					font-family:" + obj.font + ";\
					;"
            box.appendChild(temps);
            innerHolder.appendChild(box);
            obj.holder.appendChild(innerHolder);
        }

        obj.holder.style.cssText = "text-align:center;";

        if(obj.centerVerticallyInContainer){
        	innerHolder.style.cssText = "display:inline-block;position:relative;top:50%;-webkit-transform:translate(0,-50%);";
        }else{
        	innerHolder.style.cssText = "display:inline-block;position:relative;top:"+obj.topOffset+"px";
        }
        window.forecastDayCount = obj.dayCount;
    }
};